package com.cts.demo.invoke;

import java.util.Scanner;

import com.cts.demo.interfaceimplementation.PhoneOrderRepair;

public class MainMethod {
	public static void main (String args[]) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to our site. Would you like to order or repair");
		String processOption = sc.nextLine().toLowerCase().trim();
		PhoneOrderRepair phoneOrderRepair = new PhoneOrderRepair();
		String productDetail = null;

		switch (processOption) {
			case "order":
				System.out.println("Please provide the phone model name");
				productDetail = sc.nextLine().trim();
				phoneOrderRepair.ProcessOrder(productDetail);
				break;
	
			case "repair":
				System.out.println("Is it the phone or the accessory that you want to be repaired?");
				String productType = sc.nextLine().toLowerCase();
				if (productType.equals("phone")) {
					System.out.println("Please provide the phone model name");
					productDetail = sc.nextLine().trim();
					phoneOrderRepair.ProcessAccessoryRepair(productDetail);
	
				} else {
					System.out.println("Please provide the accessory detail, like headphone,tempered glass");
					productDetail = sc.nextLine().trim();
					phoneOrderRepair.ProcessAccessoryRepair(productDetail);
				}
				break;
			default:
				break;
		}
	}
}

	


	
